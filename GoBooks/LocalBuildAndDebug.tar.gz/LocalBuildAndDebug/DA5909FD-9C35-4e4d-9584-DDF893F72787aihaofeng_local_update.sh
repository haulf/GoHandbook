#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local update script.
##########################################################################################

function func_Main()
{

    updateBranchName=""

    func_GetParams $@

    echo "Update branch name is: $updateBranchName"

    echo ""
    echo ""
    echo ">>>>> Update code begin...."
    echo ""

    func_UpdateCode

    echo ">>>>> Update code end...."
    echo ""

    exit 0
}


function func_ShowUsage()
{
    echo ""
    echo "    Usage:"
    echo ""
    echo "    bash `basename $0` -b [update branch name] " >&2
    echo ""
    echo ""
    exit 1
}


function func_GetParams()
{
    if [[ $# -lt 1 ]]
    then
        func_ShowUsage
    fi

    local OPTIND
    while getopts b:h OPT ; do
        case $OPT in
            b)
                updateBranchName=$OPTARG
                ;;
            h)
                func_ShowUsage
                exit 0
                ;;
            ?)
                func_ShowUsage
                exit 1
                ;;
        esac
    done

    if [[ -z "$updateBranchName" ]]
    then
        echo "ERROR:Can not get the update branch name. "
        func_ShowUsage
    fi
}


function func_UpdateCode()
{
    path=`pwd`
    for privateRepoItem in $repoList
    do
        if [[ -d $path/${privateRepoItem} ]]; then
            echo ""
            echo ">>>>>>>>>>$path/${privateRepoItem}"
            cd $path/${privateRepoItem}
            git remote update && git clean -df && git checkout $updateBranchName && git reset --hard origin/$updateBranchName
        else
            echo "The directory of $path/${privateRepoItem} is not exist!"
        fi
    done
}

# Removed
#   android/qiku
#   android/qiku/bsp
#   android/qiku/script
#   android/qiku/manifests
#   android/qiku/prebuilts

repoList="
art
bionic
bootable/bootloader/edk2
bootable/recovery
build
dalvik
development
device
device/360OS
external
frameworks
hardware
kernel
libcore
packages
system
vendor
vendor/360OS
vendor/qiku
"

# start....
func_Main $@


