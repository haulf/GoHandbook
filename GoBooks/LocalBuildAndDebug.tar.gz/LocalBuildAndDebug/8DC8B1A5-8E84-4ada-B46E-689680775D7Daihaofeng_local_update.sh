#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local update script.
##########################################################################################

function func_Main()
{
    echo ""
    echo ""
    echo ">>>>> Update code begin..."
    echo ""
    echo ""
    updateBranchName=""

    func_GetParams $@

    echo "Update branch name is: $updateBranchName"

    func_UpdateCode

    echo ""
    echo ""
    echo ">>>>> Update code end..."
    echo ""
    echo ""

    exit 0
}


function func_ShowUsage()
{
    echo ""
    echo "Usage: bash `basename $0` -b [update branch name]" >&2
    echo ""
    exit 1
}


function func_GetParams()
{
    if [[ $# -lt 1 ]]
    then
        func_ShowUsage
    fi

    local OPTIND
    while getopts b:h OPT ; do
        case $OPT in
            b)
                updateBranchName=$OPTARG
                ;;
            h)
                func_ShowUsage
                exit 0
                ;;
            ?)
                func_ShowUsage
                exit 1
                ;;
        esac
    done

    if [[ -z "$updateBranchName" ]]
    then
        echo "ERROR:Can not get the update branch name. "
        func_ShowUsage
    fi
}


function func_UpdateCode()
{
    path=`pwd`
    for privateRepoItem in $repoList
    do
        echo ""
        echo ">>>>>>>>>> $path/${privateRepoItem}"
        cd $path/${privateRepoItem}
        git remote update && git clean -df && git checkout $updateBranchName && git reset --hard origin/$updateBranchName
    done
}


repoList="
abi
bionic
build
development
external
kernel
libnativehelper
packages
prebuilts
frameworks
vendor
bootable/bootloader/edk2
bootable/bootloader/lk
bootable/recovery
dalvik
device
device/360OS
frameworks
system
ndk
pdk
script
art
bsp
developers
hardware
libcore
sdk
vendor
vendor/qiku
vendor/360OS
"

# start...
func_Main $@


