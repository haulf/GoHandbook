#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local build script.
##########################################################################################

function func_main()
{
    echo ">>>>>build begin...."
    func_PrepareBuildEnvironment
    
    func_MakeAll
    
    #func_MakeSepolicy
    #func_MakeFramework
    #func_MakeQikuFramework
    #func_MakeServices
    #func_MakeQikuServices
    #func_MakeMtp
    #func_MakeRecoveryImage
    #func_MakeInit
    #func_MakeKernel
    #func_MakeBootImage
    #func_MakeExfat
    #func_MakeGatekeeperd
    #func_MakeBlkid
    #func_MakeBootanimation
    #func_MakeAdbd
    #func_MakeSdcard
    #func_MakeVold
    #func_MakeFsMgr
    #func_MakeFastmmi
    #func_MakeQKSettings
    #func_MakeSystemimage
    #func_MakeFrameworkRes
    #func_MakeIozone
    #func_MakeFio
    #func_MakeOtapackage
    #func_MakeStrace
    func_MakeSystemImage
    echo ">>>>>build end...."
}


function func_PrepareBuildEnvironment()
{
    #export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-amd64
    #export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
    #export PATH=$JAVA_HOME/bin:$PATH

    export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64
    export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
    export PATH=$JAVA_HOME/bin:$PATH

    func_DeleteNoneedFiles

    . build/envsetup.sh
    lunch QK1801-userdebug
}


function func_DeleteNoneedFiles()
{
    rm -rvf ~/temp
    mkdir -p ~/temp
    mv -vf device/qiku/QK1707/prebuilts_out/Android.mk ~/temp/
    mv -vf device/qiku/QK1707/prebuilts_out/platform_bsp_modem/Android.mk ~/temp/

    mv -vf frameworks/base/packages/SystemUI ~/temp/SystemUI
    mv -vf platform_testing/tests/functional/appsmoke/Android.mk ~/temp/

    touch com.qiku.safeframework_all.bm
    mv com.qiku.safeframework_all.bm device/360OS/platform_app/ 

    # revert secimage modification
    # http://10.100.13.23:8080/#/c/37
    # 
    #cd vendor
    #git revert 330512c415e2510a15382cf276ea97dada2b5c25
    #cd -   
}


function func_MakeAll()
{
    #source script/local_build_prapare.sh
    make update-api -j4
    make -j4 | tee build_log_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeSepolicy()
{
    rm -rf out/target/product/QK1707/recovery/root/sepolicy
    rm -rf out/target/product/QK1707/ota_temp/RECOVERY/RAMDISK/sepolicy
    rm -rf out/target/product/QK1707/ota_temp/BOOT/RAMDISK/sepolicy
    rm -rf out/target/product/QK1707/root/sepolicy
    rm -rf out/target/product/QK1707/obj/ETC/sepolicy.recovery_intermediates
    rm -rf out/target/product/QK1707/obj/ETC/sepolicy_intermediates
    rm -rf out/target/product/QK1707/obj/NOTICE_FILES/src/root/sepolicy.txt
    make -j4 sepolicy
}


function func_MakeFramework()
{
    make -j4 framework
}


function func_MakeQikuFramework()
{
    make -j4 qiku-framework
}


function func_MakeServices()
{
    make -j4 services
}


function func_MakeQikuServices()
{
    make -j4 qiku-services
}


function func_MakeFastmmi()
{
    rm -rf out/target/product/QK1707/system/vendor/lib/mmi_*
    rm -rf out/target/product/QK1707/system/vendor/lib64/mmi_*
    rm -rf out/target/product/QK1707/obj/SHARED_LIBRARIES/mmi_*
    rm -rf out/target/product/QK1707/symbols/system/vendor/lib/mmi_*
    rm -rf out/target/product/QK1707/symbols/system/vendor/lib64/mmi_*
    rm -rf out/target/product/QK1707/system/bin/fctd
    rm -rf out/target/product/QK1707/system/bin/fctest

    #make -j4 fctest
    #make -j4 libminui_ftm
    #make -j4 libmmi
    #make -j4 mmi_brightness
    #make -j4 mmi_audio
    #make -j4 mmi_modem
    #make -j4 mmi_gps
    #make -j4 mmi_vibrator

    #make -j4 mmi_hardver |tee build_hardver_log_`date +%Y.%m.%d-%H.%M`.log
    make -j4 fctd
}


function func_MakeMtp()
{
    make -j4 MediaProvider
    make -j4 libmtp | tee build_libmtp_log_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeRecoveryImage()
{
    rm -rf out/target/product/QK1707/recovery*
    rm -rf out/target/product/QK1707/obj/EXECUTABLES/recovery_intermediates
    rm -rf out/target/product/QK1707/obj/PACKAGING/ota_keys_intermediates/keys
    make -j4 recoveryimage | tee build_recovery_log_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeInit()
{
    make -j4 init
}


function func_MakeVold()
{
    rm -rf out/target/product/QK1707/obj/EXECUTABLES/vold_intermediates
    rm -f out/target/product/QK1707/symbols/system/bin/vold
    rm -f out/target/product/QK1707/system/bin/vold
    make -j4 vold    
}


function func_MakeKernel()
{
    source mkboot
    mkkernel | tee build_kernel_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeBootImage()
{
    rm -f out/target/product/QK1509/boot.img
    make bootimage -j4
}


function func_MakeExfat()
{
    mmm external/cmexfat
    #make ahf_cmexfat
    #make libexfat
    #make libexfat_fsck
    make libexfat_mkfs
}


function func_MakeGatekeeperd()
{
    make gatekeeperd
}


function func_MakeBlkid()
{

    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2_blkid_intermediates/LINKED/libext2_blkid.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2_blkid_intermediates/PACKED/libext2_blkid.so
    rm -rf out/target/product/QK1509/symbols/system/lib64/libext2_blkid.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2fs_intermediates/LINKED/libext2fs.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2fs_intermediates/PACKED/libext2fs.so
    rm -rf out/target/product/QK1509/symbols/system/lib64/libext2fs.so
    rm -rf out/target/product/QK1509/obj/lib/libext2fs.so
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/LINKED/blkid
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/PACKED/blkid
    rm -rf out/target/product/QK1509/symbols/system/bin/blkid
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/blkid
    rm -rf out/target/product/QK1509/system/bin/blkid
    make blkid -j4
}


function func_MakeSdcard()
{
    make sdcard -j4
}

function func_MakeAdbd()
{
    find out/target/product -name "adbd" | xargs rm -rvf
    make adbd -j4
}

function func_MakeBootanimation()
{
    find out/target/product -name "bootanimation" | xargs rm -rvf
    #make bootanimation -j4
    #mm bootanimation -j4
    mmm frameworks/base/cmds/bootanimation -j4
}

function func_MakeQKSettings()
{
    make QK_Settings -j4
}

function func_MakeSystemimage()
{
    make systemimage -j4
}

function func_MakeFrameworkRes()
{
    make framework-res -j4
}

function func_MakeIozone()
{
    make iozone -j4
}

function func_MakeFio()
{
    make fio -j4
}

function func_MakeOtapackage()
{
    make otapackage -j4
}

function func_MakeStrace()
{
    make strace -j4
    #mmm external/strace -j4
}

function func_MakeFsMgr() 
{
    make fs_mgr -j4
}

function func_MakeSystemImage()
{
    make systemimage -j16
}

# start....
func_main $@
