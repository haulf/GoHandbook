#!/bin/bash

###############################################################################
# Copyright (C) Haulf, 2018
#
# Local build script. You'd better open the function of func_MakeAll to build 
# all code at the start.
###############################################################################

function func_Main()
{
    PROJECT_NAME="QK1809"

    echo ">>>>>build begin...."
    func_PrepareBuildEnvironment

    func_MakeAll

    #func_MakeSepolicy
    #func_MakeFramework
    #func_MakeQikuFramework
    #func_MakeQikuFeature
    #func_MakeServices
    #func_MakeQikuServices
    #func_MakeMtp
    #func_MakeWlanKo
    #func_MakeExfat
    #func_MakeGatekeeperd
    #func_MakeBlkid
    #func_MakeBootanimation
    #func_MakeAdbd
    #func_MakeSdcard
    #func_MakeVold
    #func_MakeFastmmi
    #func_MakeQKSettings
    #func_MakeSystemimage
    #func_MakeFrameworkRes
    #func_MakeIozone
    #func_MakeFio
    #func_MakeOtapackage
    #func_MakeStrace

    #func_MakeSystemImage
    #func_MakeInit
    #func_MakeKernel
    #func_MakeBootImage
    #func_MakeRecoveryImage
    #func_MakeVendorImage

    echo ">>>>>build end...."
}


function func_PrepareBuildEnvironment()
{
    # Open jdk1.7
    #export JAVA_HOME=/usr/lib/jvm/java-1.7.0-openjdk-amd64
    #export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
    #export PATH=$JAVA_HOME/bin:$PATH

    # Open jdk1.8
    export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64
    export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
    export PATH=$JAVA_HOME/bin:$PATH

    func_DeleteNoneedFiles

    . build/envsetup.sh

    #lunch ${PROJECT_NAME}-userdebug
    lunch ${PROJECT_NAME}-user

    source script/build_prepare.sh
}


function func_DeleteNoneedFiles()
{
    # Remove qiku prebuilt out files.
    sed -i 's/^/#/g' device/qiku/${PROJECT_NAME}/prebuilts_out/Android.mk
    sed -i 's/^/#/g' device/qiku/${PROJECT_NAME}/prebuilts_out/bndroid.mk
    sed -i 's/^/#/g' device/qiku/${PROJECT_NAME}/prebuilts_out/out/bndroid.mk
    sed -i 's/^/#/g' device/qiku/${PROJECT_NAME}/prebuilts_out/platform_bsp_modem/Android.mk
    sed -i 's/^/#/g' device/qiku/${PROJECT_NAME}/prebuilts_out/platform_bsp_modem/bndroid.mk

    sed -i 's/^/#/g' frameworks/base/packages/SystemUI/Android.mk
    sed -i 's/^/#/g' platform_testing/tests/functional/appsmoke/Android.mk

    # Remove google original apps.
    sed -i 's/^/#/g' packages/apps/Browser2/Android.mk
    sed -i 's/^/#/g' packages/apps/Calendar/Android.mk
    sed -i 's/^/#/g' packages/apps/Camera2/Android.mk
    sed -i 's/^/#/g' packages/apps/CMFileManager/Android.mk
    sed -i 's/^/#/g' packages/apps/Gallery/Android.mk
    sed -i 's/^/#/g' packages/apps/Gallery2/Android.mk
    sed -i 's/^/#/g' packages/apps/Launcher2/Android.mk
    sed -i 's/^/#/g' packages/apps/QuickSearchBox/Android.mk
    sed -i 's/^/#/g' packages/apps/SnapdragonCamera/Android.mk
    sed -i 's/^/#/g' packages/apps/SnapdragonGallery/Android.mk
    sed -i 's/^/#/g' packages/apps/SnapdragonLauncher/Android.mk
    sed -i 's/^/#/g' packages/apps/SnapdragonMusic/Android.mk
    sed -i 's/^/#/g' packages/apps/Music/Android.mk

    sed -i 's/^/#/g' packages/screensavers/Basic/Android.mk
    sed -i 's/^/#/g' packages/screensavers/PhotoTable/Android.mk

    sed -i 's/^/#/g' packages/providers/BookmarkProvide/Android.mk

    sed -i 's/^/#/g' packages/inputmethods/OpenWnn/Android.mk

    sed -i 's/^/#/g' frameworks/base/packages/CtsShim/Android.mk
    sed -i 's/^/#/g' frameworks/base/packages/EasterEgg/Android.mk


    ### Remove qualcomm original apps.
    sed -i '/improveTouchStudio/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/MdtpService/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/libmdtpdemojni/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/MdtpDemo/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/SeempService/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/smcinvokepkgmgr/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/TelemetryService/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/dpmserviceapp/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/QtiFeedback/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/CABLService/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/Perfdump/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/QDMA/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/QSensorTest/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/QFPCalibration/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/com.quicinc.wipoweragent/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/qti-logkit/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/VoicePrintDemo/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/CNESettings/d' vendor/qcom/proprietary/common/config/device-vendor.mk
    sed -i '/VoicePrintService/d' vendor/qcom/proprietary/common/config/device-vendor.mk

    sed -i 's/^/#/g' vendor/qcom/opensource/bluetooth/wipower-host/a4wp/Android.mk
    sed -i 's/^/#/g' vendor/qcom/opensource/bluetooth/wipower-host/wipower_service/Android.mk

    sed -i 's/^/#/g' vendor/qcom/proprietary/qrdplus/Extension/apps/CarrierConfigure/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/qrdplus/Extension/apps/ConfigurationClient/demo/OmaCpDemoLauncher/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/qrdplus/Extension/apps/OmaDrmEngine/java/apps/OmaDrmEngineDemo/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/qrdplus/Extension/apps/NotePad/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/qrdplus/Extension/apps/CalendarWidget/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/FIDO/samples/SampleAuthenticatorService/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/FIDO/samples/SampleExtAuthService/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/FIDO/samples/SecureSampleAuthService/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/cne/apps/StatsPollManager/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/seccamera/sample/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/gps/SnapdragonSDKTest/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/ims-ship/rcs/java/PresenceApp/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/wipower/wbc_service_app/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/sse/QCSecureUIService/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/qcom/proprietary/telephony-apps/carrier/vzw/ims/tests/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/securemsm/seccamera/service/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/SmartCardService/GsmaServices/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/mm-audio/voiceprint/VoicePrintService/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/csm/Android.mk
    sed -i 's/^/#/g' vendor/qcom/proprietary/ui/apps/sva/audio-listen/sva/Android.mk

    sed -i 's/^/#/g' vendor/nxp/opensource/packages/apps/Nfc/Android.mk

    # Add some files.
    touch device/360OS/platform_app/qk_params1.bin
}


function func_MakeAll()
{
    source script/local_build_prapare.sh

    make update-api -j16
    #make systemimage -j16 | tee build_log_`date +%Y.%m.%d-%H.%M`.log

    # Disable JACK.
    #mkdir ahf_dist_output
    #make dist -j8 DIST_DIR=ahf_dist_output 'ANDROID_COMPILE_WITH_JACK:=false' | tee MakeDistLog_`date +%Y.%m.%d-%H.%M`.log
    make dist -j16 | tee MakeDistLog_`date +%Y.%m.%d-%H.%M`.log

    #make -j8 | tee MakeLog_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeSepolicy()
{
    rm -rf out/target/product/${PROJECT_NAME}/recovery/root/sepolicy
    rm -rf out/target/product/${PROJECT_NAME}/ota_temp/RECOVERY/RAMDISK/sepolicy
    rm -rf out/target/product/${PROJECT_NAME}/ota_temp/BOOT/RAMDISK/sepolicy
    rm -rf out/target/product/${PROJECT_NAME}/root/sepolicy
    rm -rf out/target/product/${PROJECT_NAME}/obj/ETC/sepolicy.recovery_intermediates
    rm -rf out/target/product/${PROJECT_NAME}/obj/ETC/sepolicy_intermediates
    rm -rf out/target/product/${PROJECT_NAME}/obj/NOTICE_FILES/src/root/sepolicy.txt
    make -j8 sepolicy
}


function func_MakeFramework()
{
    make -j8 framework
}


function func_MakeQikuFramework()
{
    make -j4 qiku-framework
}


function func_MakeServices()
{
    make services -j16
}

function func_MakeQikuFeature()
{
    make -j8 qiku-feature
}

function func_MakeQikuServices()
{
    make -j4 qiku-services
}


function func_MakeFastmmi()
{
#    rm -rf out/target/product/${PROJECT_NAME}/system/vendor/lib/mmi_*
#    rm -rf out/target/product/${PROJECT_NAME}/system/vendor/lib64/mmi_*
#    rm -rf out/target/product/${PROJECT_NAME}/obj/SHARED_LIBRARIES/mmi_*
#    rm -rf out/target/product/${PROJECT_NAME}/symbols/system/vendor/lib/mmi_*
#    rm -rf out/target/product/${PROJECT_NAME}/symbols/system/vendor/lib64/mmi_*
#    rm -rf out/target/product/${PROJECT_NAME}/system/bin/fctd
#    rm -rf out/target/product/${PROJECT_NAME}/system/bin/fctest

    #make -j16 fctest
    #make -j16 libminui
    #make -j16 libmmi
    make -j16 fctd
    #make -j4 mmi_brightness
    #make -j4 mmi_audio
    #make -j4 mmi_modem
    #make -j4 mmi_gps
    #make -j4 mmi_vibrator
    #make -j16 mmi_wifi
    #make -j16 mmi_sdcard
    #make -j16 mmi_audio
    #mmm vendor/qiku/proprietary/qiku_fastmmi/fct_case/audio

    #make -j4 mmi_hardver |tee build_hardver_log_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeMtp()
{
    make -j4 MediaProvider
    make -j4 libmtp | tee build_libmtp_log_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeRecoveryImage()
{
    rm -rf out/target/product/${PROJECT_NAME}/recovery*
    rm -rf out/target/product/${PROJECT_NAME}/obj/EXECUTABLES/recovery_intermediates
    rm -rf out/target/product/${PROJECT_NAME}/obj/PACKAGING/ota_keys_intermediates/keys
    make -j16 recoveryimage | tee BuildRecoveryLog_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeInit()
{
    make -j8 init
}


function func_MakeVold()
{
    rm -rf out/target/product/QK1707/obj/EXECUTABLES/vold_intermediates
    rm -f out/target/product/QK1707/symbols/system/bin/vold
    rm -f out/target/product/QK1707/system/bin/vold
    make -j4 vold
}


function func_MakeKernel()
{
    source mkboot
    mkkernel | tee build_kernel_`date +%Y.%m.%d-%H.%M`.log
}


function func_MakeBootImage()
{
    rm -f out/target/product/${PROJECT_NAME}/boot.img
    #make dtboimage -j8
    #make fs_mgr -j8
    #make init -j8
    make bootimage -j16 | tee BuildBootImg_`date +%Y.%m.%d-%H.%M`.log
    #make -j8 qca_cld3_wlan.ko
}

function func_MakeVendorImage()
{
    #rm -rf out/target/product/${PROJECT_NAME}/obj/ETC/nonplat_file_contexts_intermediates
    #rm -rf out/target/product/${PROJECT_NAME}/obj/ETC/file_contexts.bin_intermediates
    make vendorimage -j32 | tee BuildVendorImage_`date +%Y.%m.%d-%H.%M`.log
}

function func_MakeExfat()
{
    mmm external/cmexfat
    #make ahf_cmexfat
    #make libexfat
    #make libexfat_fsck
    make libexfat_mkfs
}


function func_MakeGatekeeperd()
{
    make gatekeeperd
}


function func_MakeBlkid()
{

    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2_blkid_intermediates/LINKED/libext2_blkid.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2_blkid_intermediates/PACKED/libext2_blkid.so
    rm -rf out/target/product/QK1509/symbols/system/lib64/libext2_blkid.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2fs_intermediates/LINKED/libext2fs.so
    rm -rf out/target/product/QK1509/obj/SHARED_LIBRARIES/libext2fs_intermediates/PACKED/libext2fs.so
    rm -rf out/target/product/QK1509/symbols/system/lib64/libext2fs.so
    rm -rf out/target/product/QK1509/obj/lib/libext2fs.so
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/LINKED/blkid
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/PACKED/blkid
    rm -rf out/target/product/QK1509/symbols/system/bin/blkid
    rm -rf out/target/product/QK1509/obj/EXECUTABLES/blkid_intermediates/blkid
    rm -rf out/target/product/QK1509/system/bin/blkid
    make blkid -j4
}


function func_MakeSdcard()
{
    make sdcard -j4
}

function func_MakeAdbd()
{
    find out/target/product -name "adbd" | xargs rm -rvf
    make adbd -j8
}

function func_MakeBootanimation()
{
    find out/target/product -name "bootanimation" | xargs rm -rvf
    #make bootanimation -j8
    #mm bootanimation -j4
    #mmm frameworks/base/cmds/bootanimation -j8
    make libbootanimation -j8
}

function func_MakeQKSettings()
{
    make QK_Settings -j4
}

function func_MakeFrameworkRes()
{
    make framework-res -j4
}

function func_MakeIozone()
{
    make iozone -j4
}

function func_MakeFio()
{
    make fio -j4
}

function func_MakeOtapackage()
{
    make otapackage -j4
}

function func_MakeStrace()
{
    make strace -j4
    #mmm external/strace -j4
}

function func_MakeSystemImage()
{
    make systemimage -j16 | tee BuildSystemImage_`date +%Y.%m.%d-%H.%M`.log
}

function func_MakeWlanKo()
{
    make qca_cld3_wlan.ko -j16
}


# start....
func_Main $@
