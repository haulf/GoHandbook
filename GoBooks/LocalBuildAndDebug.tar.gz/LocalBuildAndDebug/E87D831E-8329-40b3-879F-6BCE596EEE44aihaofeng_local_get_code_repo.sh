#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local get code script.
##########################################################################################

function func_Main()
{
    branchName=""
    func_GetParams $@

    echo ""
    echo ""
    echo ">>>>> Get code begin...."
    echo ""

    echo "Update branch name is: $branchName"
    func_GetCode

    echo ">>>>> Get code end...."
    echo ""

    exit 0
}


function func_ShowUsage()
{
    echo "Usage: bash `basename $0` -b [branch name] " >&2
    echo ""
    exit 1
}

function func_GetParams()
{
    if [[ $# -lt 1 ]]
    then
        func_ShowUsage
    fi

    local OPTIND
    while getopts b:h OPT ; do
        case $OPT in
            b)
                branchName=$OPTARG
                ;;
            h)
                func_ShowUsage
                exit 0
                ;;
            ?)
                func_ShowUsage
                exit 1
                ;;
        esac
    done

    if [[ -z "$branchName" ]]
    then
        echo "ERROR:Can not get the update branch name. "
        func_ShowUsage
    fi
}

function func_GetCode()
{
    repo init -u ssh://10.100.13.23:29418/android/qiku/manifests.git -b $branchName
    repo sync -c -j8
    repo forall -pc "git checkout -b $branchName origin/$branchName"
}

# start....
func_Main $@


