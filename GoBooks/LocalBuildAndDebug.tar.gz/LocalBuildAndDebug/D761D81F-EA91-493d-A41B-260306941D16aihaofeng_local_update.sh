#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local update script.
##########################################################################################

function func_Main()
{

    updateBranchName=""

    func_GetParams $@

    echo "Update branch name is: $updateBranchName"

    echo ""
    echo ""
    echo ">>>>> Update code begin...."
    echo ""

    func_UpdateCode

    echo ">>>>> Update code end...."
    echo ""

    exit 0
}


function func_ShowUsage()
{
    echo ""
    echo "    Usage:"
    echo ""
    echo "    bash `basename $0` -b [update branch name] " >&2
    echo ""
    echo ""
    exit 1
}


function func_GetParams()
{
    if [[ $# -lt 1 ]]
    then
        func_ShowUsage
    fi

    local OPTIND
    while getopts b:h OPT ; do
        case $OPT in
            b)
                updateBranchName=$OPTARG
                ;;
            h)
                func_ShowUsage
                exit 0
                ;;
            ?)
                func_ShowUsage
                exit 1
                ;;
        esac
    done

    if [[ -z "$updateBranchName" ]]
    then
        echo "ERROR:Can not get the update branch name. "
        func_ShowUsage
    fi
}


function func_UpdateCode()
{
    path=`pwd`
    for privateRepoItem in $repoList
    do
        if [[ -d $path/${privateRepoItem} ]]; then
            echo ""
            echo ">>>>>>>>>>$path/${privateRepoItem}"
            cd $path/${privateRepoItem}
            git remote update && git clean -df && git checkout $updateBranchName && git reset --hard origin/$updateBranchName
        else
            echo "The directory of $path/${privateRepoItem} is not exist!"
        fi
    done
}


repoList="
abi
bionic
build
development
external
kernel
libnativehelper
packages
prebuilts
frameworks
vendor
bootable/bootloader/edk2
bootable/bootloader/lk
bootable/recovery
dalvik
device
device/360OS
frameworks
system
ndk
pdk
script
art
bsp
developers
hardware
libcore
sdk
vendor
vendor/qiku
vendor/360OS
"

# start....
func_Main $@


