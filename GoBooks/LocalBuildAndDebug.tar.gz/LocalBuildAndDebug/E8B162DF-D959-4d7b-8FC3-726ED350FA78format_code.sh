#!/bin/bash

# Copyright (C)  aihaofeng 2017
# Format code, such as c, cpp, java, pyton, go, and so on.

function func_main()
{
    echo ">>>>>format code begin...."
    func_translate_windows_file_to_unix
    func_format_c_cpp_java_file
    func_format_python_file
    func_format_go_file
    func_clear_environment
    echo ">>>>>format code end...."
}


function func_translate_windows_file_to_unix()
{
    for f in $(find . -type f)
    do
        fromdos $f
    done
}


function func_format_c_cpp_java_file()
{
    for f in $(find . -name '*.c' -or -name '*.cpp' -or -name '*.cc' -or -name '*.h' -or -name '*.java' -type f)
    do
        astyle $f
    done
}


function func_format_python_file()
{
    for python_file in $(find . -name '*.py' -type f)
    do
        yapf -i $python_file
    done
}


function func_format_go_file()
{
    for go_file in $(find . -name '*.go' -type f)
    do
        fofmt -w $go_file
    done
}


function func_clear_environment()
{
    for f in $(find . -name '*.orig' -type f)
    do
        rm -rf $f
    done
}


# start....
func_main
