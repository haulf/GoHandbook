#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Get android studio debug code.
##########################################################################################

SRC_CODE_PATH="/qiku1/aihaofeng/debug_space/QCOM_SDM630_7.x_qiku/android/qiku"

function func_Main()
{
    echo ""
    echo ""
    echo ">>>>>get debug code begin...."
    echo ""

    func_GetDebugCode

    echo ">>>>>get debug code end...."
    echo ""

    exit 0
}

function func_GetDebugCode()
{
    mkdir -p ./debug_code
    cp -arvf $SRC_CODE_PATH/frameworks/base/core/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/drm/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/graphics/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/keystore/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/location/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/nfc-extras/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/frameworks/base/services/accessibility/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/appwidget/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/core/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/net/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/restrictions/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/usb/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/backup/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/devicepolicy/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/midi/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/print/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/usage/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/frameworks/base/services/voiceinteraction/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/frameworks/base/telecomm/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/vendor/qiku/opensource/frameworks/base/services/core/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/vendor/qiku/proprietary/frameworks/base/core/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/vendor/360OS/opensource/frameworks/base/core/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/vendor/360OS/opensource/frameworks/base/services/core/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/vendor/360OS/proprietary/frameworks/base/core/java/* ./debug_code/
    cp -arvf $SRC_CODE_PATH/vendor/360OS/proprietary/frameworks/base/services/core/java/* ./debug_code/

    cp -arvf $SRC_CODE_PATH/vendor/360OS/proprietary/frameworks/base/telephony/java/* ./debug_code/
}

# start....
func_Main $@


