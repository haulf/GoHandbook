#!/bin/bash

##########################################################################################
# Copyright (C) aihaofeng, 2017
# Local get code script.
##########################################################################################

function func_Main()
{
    branchName=""
    func_GetParams $@

    echo ""
    echo ""
    echo ">>>>> Get code begin...."
    echo ""

    echo "branch name is: $branchName"
    func_GetCode

    echo ">>>>> Get code end...."
    echo ""

    exit 0
}


function func_ShowUsage()
{
    echo ""
    echo ""
    echo "    Usage: bash `basename $0` -b [branch name] " >&2
    echo ""
    exit 1
}

function func_GetParams()
{
    if [[ $# -lt 1 ]]
    then
        func_ShowUsage
    fi

    local OPTIND
    while getopts b:h OPT ; do
        case $OPT in
            b)
                branchName=$OPTARG
                ;;
            h)
                func_ShowUsage
                exit 0
                ;;
            ?)
                func_ShowUsage
                exit 1
                ;;
        esac
    done

    if [[ -z "$branchName" ]]
    then
        echo "ERROR:Can not get the update branch name. "
        func_ShowUsage
    fi
}

function func_GetCode()
{
	# step(1)
    git clone ssh://aihaofeng@10.100.13.23:29418/android/qiku.git android/qiku
    cd android/qiku
    git checkout -b $branchName origin/$branchName
    rm -rvf .git
    cd -

    # step(2)
    path=`pwd`
    for privateRepoItem in $repoList
    do
        echo ""
        echo ""
        mkdir -p $path/$privateRepoItem

        git clone ssh://aihaofeng@10.100.13.23:29418/$privateRepoItem $privateRepoItem

        cd $privateRepoItem
        git checkout -b $branchName origin/$branchName

        #if [[ ${privateRepoItem}x == "kernel"x ]]; then
        #    git checkout -b QCOM_SDM660_8.x_minimal_1707_1801 origin/QCOM_SDM660_8.x_minimal_1707_1801
        #else
        #    git checkout -b $branchName origin/$branchName
        #fi
        cd -
    done
}

repoList="
android/qiku/art
android/qiku/bionic
android/qiku/bootable/bootloader/edk2
android/qiku/bootable/recovery
android/qiku/bsp
android/qiku/build
android/qiku/dalvik
android/qiku/development
android/qiku/device
android/qiku/device/360OS
android/qiku/external
android/qiku/frameworks
android/qiku/hardware
android/qiku/kernel
android/qiku/libcore
android/qiku/manifests
android/qiku/packages
android/qiku/prebuilts
android/qiku/script
android/qiku/system
android/qiku/vendor
android/qiku/vendor/360OS
android/qiku/vendor/qiku
"

# start....
func_Main $@


